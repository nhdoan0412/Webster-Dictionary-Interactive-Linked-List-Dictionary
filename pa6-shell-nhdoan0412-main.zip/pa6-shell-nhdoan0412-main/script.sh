pwd
ls
du -hd1
